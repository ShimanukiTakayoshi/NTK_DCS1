﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDebug
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TextBox24 = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TextBox25 = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.TextBox27 = New System.Windows.Forms.TextBox()
        Me.TextBox28 = New System.Windows.Forms.TextBox()
        Me.TextBox29 = New System.Windows.Forms.TextBox()
        Me.TextBox30 = New System.Windows.Forms.TextBox()
        Me.TextBox31 = New System.Windows.Forms.TextBox()
        Me.TextBox32 = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TextBox33 = New System.Windows.Forms.TextBox()
        Me.TextBox34 = New System.Windows.Forms.TextBox()
        Me.TextBox35 = New System.Windows.Forms.TextBox()
        Me.TextBox36 = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.TextBox37 = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.TextBox38 = New System.Windows.Forms.TextBox()
        Me.TextBox39 = New System.Windows.Forms.TextBox()
        Me.TextBox40 = New System.Windows.Forms.TextBox()
        Me.TextBox41 = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.TextBox42 = New System.Windows.Forms.TextBox()
        Me.TextBox43 = New System.Windows.Forms.TextBox()
        Me.TextBox44 = New System.Windows.Forms.TextBox()
        Me.TextBox45 = New System.Windows.Forms.TextBox()
        Me.TextBox46 = New System.Windows.Forms.TextBox()
        Me.TextBox47 = New System.Windows.Forms.TextBox()
        Me.TextBox48 = New System.Windows.Forms.TextBox()
        Me.TextBox49 = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.TextBox50 = New System.Windows.Forms.TextBox()
        Me.TextBox51 = New System.Windows.Forms.TextBox()
        Me.TextBox52 = New System.Windows.Forms.TextBox()
        Me.TextBox53 = New System.Windows.Forms.TextBox()
        Me.TextBox54 = New System.Windows.Forms.TextBox()
        Me.TextBox55 = New System.Windows.Forms.TextBox()
        Me.TextBox56 = New System.Windows.Forms.TextBox()
        Me.TextBox57 = New System.Windows.Forms.TextBox()
        Me.TextBox58 = New System.Windows.Forms.TextBox()
        Me.TextBox59 = New System.Windows.Forms.TextBox()
        Me.TextBox60 = New System.Windows.Forms.TextBox()
        Me.TextBox61 = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(49, 8)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(78, 19)
        Me.TextBox1.TabIndex = 0
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(49, 33)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(78, 19)
        Me.TextBox2.TabIndex = 1
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(49, 58)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(78, 19)
        Me.TextBox3.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 12)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "品番"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 36)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(21, 12)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Lot"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(8, 61)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(41, 12)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "作業者"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(8, 86)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(33, 12)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Plobe"
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(49, 83)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(78, 19)
        Me.TextBox4.TabIndex = 6
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(49, 108)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(78, 19)
        Me.TextBox5.TabIndex = 8
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(49, 133)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(78, 19)
        Me.TextBox6.TabIndex = 9
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(49, 158)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(78, 19)
        Me.TextBox7.TabIndex = 10
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(49, 183)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(78, 19)
        Me.TextBox8.TabIndex = 11
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(49, 208)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(78, 19)
        Me.TextBox9.TabIndex = 12
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(49, 233)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(78, 19)
        Me.TextBox10.TabIndex = 13
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(49, 258)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(78, 19)
        Me.TextBox11.TabIndex = 14
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(8, 286)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(37, 12)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "さやNo"
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(49, 283)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(78, 19)
        Me.TextBox12.TabIndex = 15
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(8, 311)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(36, 12)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "さやPo"
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(49, 308)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(78, 19)
        Me.TextBox13.TabIndex = 17
        '
        'TextBox14
        '
        Me.TextBox14.Location = New System.Drawing.Point(49, 333)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(78, 19)
        Me.TextBox14.TabIndex = 19
        '
        'TextBox15
        '
        Me.TextBox15.Location = New System.Drawing.Point(49, 358)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(78, 19)
        Me.TextBox15.TabIndex = 20
        '
        'TextBox16
        '
        Me.TextBox16.Location = New System.Drawing.Point(49, 383)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(78, 19)
        Me.TextBox16.TabIndex = 21
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(8, 411)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(38, 12)
        Me.Label7.TabIndex = 23
        Me.Label7.Text = "INDEX"
        '
        'TextBox17
        '
        Me.TextBox17.Location = New System.Drawing.Point(49, 408)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(78, 19)
        Me.TextBox17.TabIndex = 22
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(139, 11)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(41, 12)
        Me.Label8.TabIndex = 25
        Me.Label8.Text = "位置決"
        '
        'TextBox18
        '
        Me.TextBox18.Location = New System.Drawing.Point(186, 7)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(78, 19)
        Me.TextBox18.TabIndex = 24
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(139, 36)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(29, 12)
        Me.Label9.TabIndex = 27
        Me.Label9.Text = "検知"
        '
        'TextBox19
        '
        Me.TextBox19.Location = New System.Drawing.Point(186, 32)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(78, 19)
        Me.TextBox19.TabIndex = 26
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(139, 61)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(35, 12)
        Me.Label10.TabIndex = 29
        Me.Label10.Text = "全長1"
        '
        'TextBox20
        '
        Me.TextBox20.Location = New System.Drawing.Point(186, 57)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(78, 19)
        Me.TextBox20.TabIndex = 28
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(139, 86)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(35, 12)
        Me.Label11.TabIndex = 31
        Me.Label11.Text = "全長2"
        '
        'TextBox21
        '
        Me.TextBox21.Location = New System.Drawing.Point(186, 82)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(78, 19)
        Me.TextBox21.TabIndex = 30
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(139, 111)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(41, 12)
        Me.Label12.TabIndex = 33
        Me.Label12.Text = "ﾘﾄ検知"
        '
        'TextBox22
        '
        Me.TextBox22.Location = New System.Drawing.Point(186, 107)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(78, 19)
        Me.TextBox22.TabIndex = 32
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(139, 137)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(35, 12)
        Me.Label13.TabIndex = 35
        Me.Label13.Text = "ﾘﾄ全1"
        '
        'TextBox23
        '
        Me.TextBox23.Location = New System.Drawing.Point(186, 133)
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(78, 19)
        Me.TextBox23.TabIndex = 34
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(139, 162)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(35, 12)
        Me.Label14.TabIndex = 37
        Me.Label14.Text = "ﾘﾄ全2"
        '
        'TextBox24
        '
        Me.TextBox24.Location = New System.Drawing.Point(186, 158)
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.Size = New System.Drawing.Size(78, 19)
        Me.TextBox24.TabIndex = 36
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(139, 187)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(29, 12)
        Me.Label15.TabIndex = 39
        Me.Label15.Text = "在荷"
        '
        'TextBox25
        '
        Me.TextBox25.Location = New System.Drawing.Point(186, 183)
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(78, 19)
        Me.TextBox25.TabIndex = 38
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(554, 36)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(37, 12)
        Me.Label16.TabIndex = 41
        Me.Label16.Text = "R検知"
        '
        'TextBox26
        '
        Me.TextBox26.Location = New System.Drawing.Point(601, 32)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(78, 19)
        Me.TextBox26.TabIndex = 40
        '
        'TextBox27
        '
        Me.TextBox27.Location = New System.Drawing.Point(601, 58)
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.Size = New System.Drawing.Size(78, 19)
        Me.TextBox27.TabIndex = 42
        '
        'TextBox28
        '
        Me.TextBox28.Location = New System.Drawing.Point(601, 83)
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Size = New System.Drawing.Size(78, 19)
        Me.TextBox28.TabIndex = 43
        '
        'TextBox29
        '
        Me.TextBox29.Location = New System.Drawing.Point(601, 107)
        Me.TextBox29.Name = "TextBox29"
        Me.TextBox29.Size = New System.Drawing.Size(78, 19)
        Me.TextBox29.TabIndex = 44
        '
        'TextBox30
        '
        Me.TextBox30.Location = New System.Drawing.Point(601, 133)
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.Size = New System.Drawing.Size(78, 19)
        Me.TextBox30.TabIndex = 49
        '
        'TextBox31
        '
        Me.TextBox31.Location = New System.Drawing.Point(601, 158)
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.Size = New System.Drawing.Size(78, 19)
        Me.TextBox31.TabIndex = 48
        '
        'TextBox32
        '
        Me.TextBox32.Location = New System.Drawing.Point(601, 184)
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.Size = New System.Drawing.Size(78, 19)
        Me.TextBox32.TabIndex = 47
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(554, 137)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(31, 12)
        Me.Label17.TabIndex = 46
        Me.Label17.Text = "R全1"
        '
        'TextBox33
        '
        Me.TextBox33.Location = New System.Drawing.Point(601, 208)
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.Size = New System.Drawing.Size(78, 19)
        Me.TextBox33.TabIndex = 45
        '
        'TextBox34
        '
        Me.TextBox34.Location = New System.Drawing.Point(601, 233)
        Me.TextBox34.Name = "TextBox34"
        Me.TextBox34.Size = New System.Drawing.Size(78, 19)
        Me.TextBox34.TabIndex = 54
        '
        'TextBox35
        '
        Me.TextBox35.Location = New System.Drawing.Point(601, 258)
        Me.TextBox35.Name = "TextBox35"
        Me.TextBox35.Size = New System.Drawing.Size(78, 19)
        Me.TextBox35.TabIndex = 53
        '
        'TextBox36
        '
        Me.TextBox36.Location = New System.Drawing.Point(601, 283)
        Me.TextBox36.Name = "TextBox36"
        Me.TextBox36.Size = New System.Drawing.Size(78, 19)
        Me.TextBox36.TabIndex = 52
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(554, 237)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(31, 12)
        Me.Label18.TabIndex = 51
        Me.Label18.Text = "R全2"
        '
        'TextBox37
        '
        Me.TextBox37.Location = New System.Drawing.Point(601, 308)
        Me.TextBox37.Name = "TextBox37"
        Me.TextBox37.Size = New System.Drawing.Size(78, 19)
        Me.TextBox37.TabIndex = 50
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(299, 15)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(43, 12)
        Me.Label19.TabIndex = 55
        Me.Label19.Text = "検知ST"
        '
        'TextBox38
        '
        Me.TextBox38.Location = New System.Drawing.Point(280, 33)
        Me.TextBox38.Name = "TextBox38"
        Me.TextBox38.Size = New System.Drawing.Size(78, 19)
        Me.TextBox38.TabIndex = 56
        '
        'TextBox39
        '
        Me.TextBox39.Location = New System.Drawing.Point(280, 58)
        Me.TextBox39.Name = "TextBox39"
        Me.TextBox39.Size = New System.Drawing.Size(78, 19)
        Me.TextBox39.TabIndex = 57
        '
        'TextBox40
        '
        Me.TextBox40.Location = New System.Drawing.Point(280, 83)
        Me.TextBox40.Name = "TextBox40"
        Me.TextBox40.Size = New System.Drawing.Size(78, 19)
        Me.TextBox40.TabIndex = 58
        '
        'TextBox41
        '
        Me.TextBox41.Location = New System.Drawing.Point(280, 107)
        Me.TextBox41.Name = "TextBox41"
        Me.TextBox41.Size = New System.Drawing.Size(78, 19)
        Me.TextBox41.TabIndex = 59
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(392, 15)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(37, 12)
        Me.Label20.TabIndex = 60
        Me.Label20.Text = "全1ST"
        '
        'TextBox42
        '
        Me.TextBox42.Location = New System.Drawing.Point(375, 33)
        Me.TextBox42.Name = "TextBox42"
        Me.TextBox42.Size = New System.Drawing.Size(78, 19)
        Me.TextBox42.TabIndex = 61
        '
        'TextBox43
        '
        Me.TextBox43.Location = New System.Drawing.Point(375, 58)
        Me.TextBox43.Name = "TextBox43"
        Me.TextBox43.Size = New System.Drawing.Size(78, 19)
        Me.TextBox43.TabIndex = 62
        '
        'TextBox44
        '
        Me.TextBox44.Location = New System.Drawing.Point(375, 82)
        Me.TextBox44.Name = "TextBox44"
        Me.TextBox44.Size = New System.Drawing.Size(78, 19)
        Me.TextBox44.TabIndex = 63
        '
        'TextBox45
        '
        Me.TextBox45.Location = New System.Drawing.Point(375, 108)
        Me.TextBox45.Name = "TextBox45"
        Me.TextBox45.Size = New System.Drawing.Size(78, 19)
        Me.TextBox45.TabIndex = 64
        '
        'TextBox46
        '
        Me.TextBox46.Location = New System.Drawing.Point(375, 134)
        Me.TextBox46.Name = "TextBox46"
        Me.TextBox46.Size = New System.Drawing.Size(78, 19)
        Me.TextBox46.TabIndex = 65
        '
        'TextBox47
        '
        Me.TextBox47.Location = New System.Drawing.Point(375, 159)
        Me.TextBox47.Name = "TextBox47"
        Me.TextBox47.Size = New System.Drawing.Size(78, 19)
        Me.TextBox47.TabIndex = 66
        '
        'TextBox48
        '
        Me.TextBox48.Location = New System.Drawing.Point(375, 184)
        Me.TextBox48.Name = "TextBox48"
        Me.TextBox48.Size = New System.Drawing.Size(78, 19)
        Me.TextBox48.TabIndex = 67
        '
        'TextBox49
        '
        Me.TextBox49.Location = New System.Drawing.Point(375, 208)
        Me.TextBox49.Name = "TextBox49"
        Me.TextBox49.Size = New System.Drawing.Size(78, 19)
        Me.TextBox49.TabIndex = 68
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(488, 15)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(37, 12)
        Me.Label21.TabIndex = 69
        Me.Label21.Text = "全2ST"
        '
        'TextBox50
        '
        Me.TextBox50.Location = New System.Drawing.Point(471, 33)
        Me.TextBox50.Name = "TextBox50"
        Me.TextBox50.Size = New System.Drawing.Size(78, 19)
        Me.TextBox50.TabIndex = 70
        '
        'TextBox51
        '
        Me.TextBox51.Location = New System.Drawing.Point(471, 58)
        Me.TextBox51.Name = "TextBox51"
        Me.TextBox51.Size = New System.Drawing.Size(78, 19)
        Me.TextBox51.TabIndex = 71
        '
        'TextBox52
        '
        Me.TextBox52.Location = New System.Drawing.Point(471, 83)
        Me.TextBox52.Name = "TextBox52"
        Me.TextBox52.Size = New System.Drawing.Size(78, 19)
        Me.TextBox52.TabIndex = 72
        '
        'TextBox53
        '
        Me.TextBox53.Location = New System.Drawing.Point(471, 108)
        Me.TextBox53.Name = "TextBox53"
        Me.TextBox53.Size = New System.Drawing.Size(78, 19)
        Me.TextBox53.TabIndex = 73
        '
        'TextBox54
        '
        Me.TextBox54.Location = New System.Drawing.Point(471, 134)
        Me.TextBox54.Name = "TextBox54"
        Me.TextBox54.Size = New System.Drawing.Size(78, 19)
        Me.TextBox54.TabIndex = 74
        '
        'TextBox55
        '
        Me.TextBox55.Location = New System.Drawing.Point(471, 159)
        Me.TextBox55.Name = "TextBox55"
        Me.TextBox55.Size = New System.Drawing.Size(78, 19)
        Me.TextBox55.TabIndex = 75
        '
        'TextBox56
        '
        Me.TextBox56.Location = New System.Drawing.Point(471, 184)
        Me.TextBox56.Name = "TextBox56"
        Me.TextBox56.Size = New System.Drawing.Size(78, 19)
        Me.TextBox56.TabIndex = 76
        '
        'TextBox57
        '
        Me.TextBox57.Location = New System.Drawing.Point(471, 208)
        Me.TextBox57.Name = "TextBox57"
        Me.TextBox57.Size = New System.Drawing.Size(78, 19)
        Me.TextBox57.TabIndex = 77
        '
        'TextBox58
        '
        Me.TextBox58.Location = New System.Drawing.Point(471, 233)
        Me.TextBox58.Name = "TextBox58"
        Me.TextBox58.Size = New System.Drawing.Size(78, 19)
        Me.TextBox58.TabIndex = 78
        '
        'TextBox59
        '
        Me.TextBox59.Location = New System.Drawing.Point(471, 258)
        Me.TextBox59.Name = "TextBox59"
        Me.TextBox59.Size = New System.Drawing.Size(78, 19)
        Me.TextBox59.TabIndex = 79
        '
        'TextBox60
        '
        Me.TextBox60.Location = New System.Drawing.Point(471, 283)
        Me.TextBox60.Name = "TextBox60"
        Me.TextBox60.Size = New System.Drawing.Size(78, 19)
        Me.TextBox60.TabIndex = 80
        '
        'TextBox61
        '
        Me.TextBox61.Location = New System.Drawing.Point(471, 308)
        Me.TextBox61.Name = "TextBox61"
        Me.TextBox61.Size = New System.Drawing.Size(78, 19)
        Me.TextBox61.TabIndex = 81
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(620, 14)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(43, 12)
        Me.Label22.TabIndex = 82
        Me.Label22.Text = "取出ST"
        '
        'frmDebug
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(701, 441)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.TextBox61)
        Me.Controls.Add(Me.TextBox60)
        Me.Controls.Add(Me.TextBox59)
        Me.Controls.Add(Me.TextBox58)
        Me.Controls.Add(Me.TextBox57)
        Me.Controls.Add(Me.TextBox56)
        Me.Controls.Add(Me.TextBox55)
        Me.Controls.Add(Me.TextBox54)
        Me.Controls.Add(Me.TextBox53)
        Me.Controls.Add(Me.TextBox52)
        Me.Controls.Add(Me.TextBox51)
        Me.Controls.Add(Me.TextBox50)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.TextBox49)
        Me.Controls.Add(Me.TextBox48)
        Me.Controls.Add(Me.TextBox47)
        Me.Controls.Add(Me.TextBox46)
        Me.Controls.Add(Me.TextBox45)
        Me.Controls.Add(Me.TextBox44)
        Me.Controls.Add(Me.TextBox43)
        Me.Controls.Add(Me.TextBox42)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.TextBox41)
        Me.Controls.Add(Me.TextBox40)
        Me.Controls.Add(Me.TextBox39)
        Me.Controls.Add(Me.TextBox38)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.TextBox34)
        Me.Controls.Add(Me.TextBox35)
        Me.Controls.Add(Me.TextBox36)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.TextBox37)
        Me.Controls.Add(Me.TextBox30)
        Me.Controls.Add(Me.TextBox31)
        Me.Controls.Add(Me.TextBox32)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.TextBox33)
        Me.Controls.Add(Me.TextBox29)
        Me.Controls.Add(Me.TextBox28)
        Me.Controls.Add(Me.TextBox27)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.TextBox26)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.TextBox25)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.TextBox24)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.TextBox23)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.TextBox22)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.TextBox21)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.TextBox20)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.TextBox19)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.TextBox18)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.TextBox17)
        Me.Controls.Add(Me.TextBox16)
        Me.Controls.Add(Me.TextBox15)
        Me.Controls.Add(Me.TextBox14)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.TextBox13)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TextBox12)
        Me.Controls.Add(Me.TextBox11)
        Me.Controls.Add(Me.TextBox10)
        Me.Controls.Add(Me.TextBox9)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Name = "frmDebug"
        Me.Text = "frmDebug"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents TextBox21 As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TextBox22 As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents TextBox23 As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents TextBox24 As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TextBox25 As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents TextBox26 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox27 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox28 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox29 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox30 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox31 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox32 As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents TextBox33 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox34 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox35 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox36 As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents TextBox37 As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents TextBox38 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox39 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox40 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox41 As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents TextBox42 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox43 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox44 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox45 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox46 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox47 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox48 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox49 As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents TextBox50 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox51 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox52 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox53 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox54 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox55 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox56 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox57 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox58 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox59 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox60 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox61 As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
End Class
